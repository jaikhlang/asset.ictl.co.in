<section id="sponsors" class="white lighten-3 sponsor" style="overflow: hidden;">
  <div class="container">
    <div class="row" style="padding-top: 20px;">
        <!--div class="col s12 m12 center">
          <div class="publisher" style="">
            <p class="grey-text">Publishing Partner &amp; Sponsors</p>
            <a href="<?php echo e(url('http://www.mrbpublishers.com')); ?>">
              <span class="card-panel white" style="display: inline-block; overflow: hidden">
                  <img src="<?php echo e(asset('image/sponsors/mrb.png')); ?>" alt="">
              </span>
            </a>
          </div>
        </div-->

        <div class="col s12 m12">
          <h5 class="black-text">Our sponsors</h5>
        </div>

        <div class="col s12 m12">
          <div class="owl-carousel white" id="owl-carousel1">
            <div class="item" style=""><a href="<?php echo e(url('http://www.cambridgeindia.org')); ?>" target="_blank"><img src="<?php echo e(asset('image/sponsors/chambridge.png')); ?>" alt=""></a></div>
            <div class="item" style=""><a href="<?php echo e(url('http://www.daphnesystems.com')); ?>" target="_blank"><img src="<?php echo e(asset('image/sponsors/daphne.jpg')); ?>" alt=""></a></div>
            <div class="item" style=""><a href="<?php echo e(url('http://www.elsevier.co.in')); ?>" target="_blank"><img src="<?php echo e(asset('image/sponsors/elsevier.jpg')); ?>" alt=""></a></div>
            <div class="item" style=""><a href="<?php echo e(url('http://www.mrbpublishers.com')); ?>" target="_blank"><img src="<?php echo e(asset('image/sponsors/mrb.jpg')); ?>" alt=""></a></div>
            <div class="item" style=""><a href="<?php echo e(url('http://www.pearsoned.com')); ?>" target="_blank"><img src="<?php echo e(asset('image/sponsors/pearsonw.png')); ?>" alt=""></a></div>
            <div class="item" style=""><a href="<?php echo e(url('http://www.shankarsbook.com/')); ?>" target="_blank"><img src="<?php echo e(asset('image/sponsors/shankar.png')); ?>" alt=""></a></div>
            <div class="item" style=""><a href="<?php echo e(url('http://www.springer.com')); ?>" target="_blank"><img src="<?php echo e(asset('image/sponsors/springer.jpg')); ?>" alt=""></a></div>
            <div class="item" style=""><a href="<?php echo e(url('http://taylorandfrancis.com')); ?>" target="_blank"><img src="<?php echo e(asset('image/sponsors/taylor.jpg')); ?>" alt=""></a></div>
            <div class="item" style=""><a href="<?php echo e(url('https://www.cengage.co.in')); ?>" target="_blank"><img src="<?php echo e(asset('image/sponsors/cangage.jpg')); ?>" alt=""></a></div>
            <div class="item" style=""><a href="<?php echo e(url('https://www.google.co.in/search?q=national+book+distributors+guwahati')); ?>" target="_blank"><img src="<?php echo e(asset('image/sponsors/nbd.jpg')); ?>" alt=""></a></div>
            <div class="item" style=""><a href="<?php echo e(url('#!')); ?>" target="_blank"><img src="<?php echo e(asset('image/sponsors/jnm.jpg')); ?>" alt=""></a></div>
          </div>
        </div>
    </div>
  </div>
</section>

<style>
.sponsor{
    /*
    background: radial-gradient(at 50% 0, rgba(9, 5, 4, 0.2),transparent 60%);
    background-size: 100% 40px;
    background-repeat: no-repeat;
    margin: 0;
    width: 100%;
    overflow: hidden;
    */
}
</style>
